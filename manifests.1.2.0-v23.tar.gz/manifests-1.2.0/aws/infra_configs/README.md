This directory contains some additional configuration files that are used by kfctl when
deploying on AWS.